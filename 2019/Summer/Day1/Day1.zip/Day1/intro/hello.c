#include <stdio.h>
int main()
{
  char msg[] = "Hello world\n";
  printf("%s\n",msg);
  return 0;
}
