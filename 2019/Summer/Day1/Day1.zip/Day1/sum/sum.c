#include <stdio.h>

int func(int level) {
	int sum = 0;

	for(int i=1; i<=level; ++i)
		sum += i;

	return sum;
}

int main(void) {
	int sum = 0, level = 0;

	scanf("%d", &level);
	sum = func(level);
	printf("Sum: %d\n", sum);

	return 0;
}
