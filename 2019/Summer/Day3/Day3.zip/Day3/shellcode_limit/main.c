#include <stdio.h>
int main() {
	void (*ptr)();
	char buf[0x20];
	puts("shellcode>>");
	read(0, buf, 20);
	ptr = buf;
	ptr();
}
