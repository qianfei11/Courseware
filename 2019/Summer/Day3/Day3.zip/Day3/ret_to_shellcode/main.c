#include <stdio.h>
#include <stdlib.h>
#include <string.h>

char username[0x20];

void vul() {
	printf("Please input username:\n");
	read(0, username, 0x20);
	char password[0x20];
	printf("Please input password:\n");
	gets(password);
	if (strcmp(username, "admin\n") != 0 && strcmp(password, "admin123") != 0) {
		printf("Who are you!\n");
		return;
	}
	printf("Welcome to \'NOTHING\'!\n");
}

int main() {
	vul();
	return 0;
}
