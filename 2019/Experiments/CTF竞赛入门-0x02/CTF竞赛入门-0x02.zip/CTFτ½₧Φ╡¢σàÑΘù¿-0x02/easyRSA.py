#!/usr/bin/env python
import gmpy2
import libnum

e = 0x10001
p = 0x1d6329f1c35ca4bfabb9f5610000000079L
q = 0x100000000000000000000000000000033L
c = 0x1afdbbb718c7419b34f7332df72e966cfce6f00f3b564276346ebdc8fed32e54c5L
n = p * q
phi = (p - 1) * (q - 1)

d = gmpy2.invert(e, phi)
m = gmpy2.powmod(c, d, n)
flag = libnum.n2s(m)
print flag

