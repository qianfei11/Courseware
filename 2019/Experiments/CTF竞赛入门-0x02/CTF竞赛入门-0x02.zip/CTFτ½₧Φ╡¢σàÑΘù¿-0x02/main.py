#!/usr/bin/env python
from utils import *

if __name__ == '__main__':
    m = raw_input('Please input your message: ')
    n = s2n(m)
    print 'Convert to number:', n
    s = n2s(n)
    print 'Convert to string:', s

