#!/usr/bin/env python

__author__='assassinq'

def s2n(s): # translate string to number
    res = ''
    for i in range(len(s)):
        res += hex(ord(s[i]))[2:]
    n = int(res, 16)
    return n

def n2s(n): # translate number to string
    num = hex(n)[2:].replace('L', '')
    s = ''
    for i in range(len(num) / 2):
        s += chr(int(num[2*i:2*i+2],16))
    return s

