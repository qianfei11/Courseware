# CTF竞赛入门-0x02

目录结构：

```
.
├── CTF竞赛入门-0x02.pdf
├── utils.py
├── utils.pyc
├── main.py
├── easyElGamal.txt
├── easyElGamal.py
├── easyRSA.txt
├── easyRSA.py
└── Wilson.py

0 directories, 9 files
```

## CTF竞赛入门-0x02.pdf

本次课程课件。

## utils

对应`libnum`中字符串和整数之间进行相互转换两个函数（`n2s`和`s2n`）的实现。

## main.py

使用`utils.py`的测试脚本。

## easyElGamal

`easyElGamal.txt`：简单的ElGamal类题型。
`easyElGamal.py`：对应解题的python脚本。


## easyRSA

`easyRSA.txt`：简单的RSA类题型。
`easyRSA.py`：对应解题的python脚本。

## Wilson.py

涉及到威尔逊（Wilson）定律的RSA题型。

