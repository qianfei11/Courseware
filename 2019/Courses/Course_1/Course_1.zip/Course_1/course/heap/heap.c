#include <stdio.h>
#include <stdlib.h>

int main() {
	void *p, *q, *r, *s;
	p = malloc(150);
	q = malloc(150);
	r = malloc(150);
	s = malloc(150);
	free(p);
	free(r);
	return 0;
}
