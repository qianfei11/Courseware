---
title: Reverse Engineering 101

---

## Reverse Engineering 101

IS-1701 [B3ale](http://blog.b3ale.cn/)

<img src="./hifive.gif" width=600/>

----

[CTF Wiki](https://ctf-wiki.github.io/ctf-wiki/)

- WEB包括对各类代码的阅读能力, 简单脚本的编写能力, 以及对各类漏洞的理解;
- MISC包括对各类计算机相关知识的理解, 脑洞大, 需要较好的关联性和跳跃性思维,简单脚本的编写能力, 熟练使用搜索引擎;
- CRYPTO需要数论方面的知识,对各类加解密算法的理解,简单脚本的编写能力;
- PWN, **<font color="#FF0000">REVERSE</font>**包括对计算机操作系统的理解, 堆栈的理解, 常规的GDB, IDA, OD等软件的熟练使用, 对汇编, C的理解.

----

## [How To Ask Questions The Smart Way](https://github.com/ryanhanwu/How-To-Ask-Questions-The-Smart-Way/blob/master/README-zh_CN.md)

---

## Reverse Engineering 101

- 什么是逆向工程?
- 基础知识
  - 调试(基于VS等编译器), 汇编, Linux
- 逆向工具使用
  - OllyDbg(Win下32位程序动态调试)
  - IDA Pro(静态分析, 也可动态调试)
  - GCC(Linux编译), GDB(Linux调试)

---

## 什么是逆向工程?

对一项目标产品进行逆向分析及研究, 从而演绎并得出该产品的处理流程, 组织结构, 功能性能规格等设计要素, 以制作出功能相近, 但又不完全一样的产品. 逆向工程源于商业及军事领域中的硬件分析. 其主要目的是, 在无法轻易获得必要的生产信息下, 直接从成品的分析, 推导产品的设计原理.

----

## 逆向工程

- 逆向软件/程序
  - 软件破解
  - 游戏外挂
- 其他领域
  - [如何看待中国在部分高科技领域的逆向工程案例](https://www.zhihu.com/question/28922791)

----

## 逆向分析方法

- **静态分析**: 在不运行计算机程序的条件下, 配合静态程序分析工具进行程序分析的方法;
- **动态调试**: 使用编译器或调试软件跟踪程序运行, 来查找定位程序逻辑的方法.

---

## 基础知识: 调试

**调试**(Debug)是发现和减少计算机程序或电子仪器设备中程序错误的一个过程.

演示环境: Visual Studio 2015

----

## [调试快捷键(Visual Studio)](https://blog.csdn.net/cheriyou_/article/details/79018037)

快捷键|功能
:-:|:-:
F5|运行程序
F9|设置断点
F10|单步步过
F11|单步步入

----

## 调试代码

```c
#include <stdio.h>

int main() {
    int a = 1, b = 1, c;
    for (int i = 0; i < 10; i++) {
        c = a + b;
        a = b;
        b = c;
    }
}
```

---

## 基础知识: 汇编入门

任何一种用于电子计算机, 微处理器, 微控制器, 或其他可编程器件的低级语言. 在不同的设备中, 汇编语言对应着不同的机器语言指令集. 一种汇编语言专用于某种计算机系统结构, 而不像许多高级语言, 可以在不同系统平台之间移植. 使用汇编语言编写的源代码, 然后通过相应的汇编程序将它们转换成可执行的机器代码.

[汇编语言入门教程 - 阮一峰的网络日志](http://www.ruanyifeng.com/blog/2018/01/assembly-language-primer.html)

----

## 高级语言和低级语言

<img src="./asm.png" width=800>

----

## CPU的运行方式

取出下一条要执行的汇编指令, 执行当前指令, 输出结果.

----

## 寄存器

寄存器是中央处理器内用来暂存指令, 数据和地址的电脑存储器. 寄存器的存贮容量有限, 读写速度非常快. 在计算机体系结构里, 寄存器存储在已知时间点所作计算的中间结果, 通过快速地访问数据来加速计算机程序的运行. 寄存器位于存储器层次结构的最顶端, 是CPU可以读写的最快的存储器.

----

## 通用寄存器

寄存器|功能
:-:|:-:
AX|累加器,可存放函数返回值
BX|基址寄存器,内存寻址
CX|计数器,用于循环
DX|数据寄存器

----

## 其他寄存器

寄存器|功能
:-:|:-:
SI|起始索引寄存器
DI|目的索引寄存器
SP|栈顶寄存器
BP|栈底寄存器
IP|指令寄存器

----

<img src="./registers.png" width=900/>

----

## [常用汇编指令](https://blog.csdn.net/linjasmine/article/details/3030966)

指令|功能
:-:|:-:
MOV|赋值
ADD/SUB/MUL/DIV|加/减/乘/除
AND/OR/NOT/XOR|与/或/非/异或
JMP|跳转

----

## 汇编语言风格

<font size="6">Intel语法</font>|<font size="6">AT&T语法</font>
:-:|:-:
<font size="6">`mov al, bl`</font>|<font size="6">`movb %bl, %al`</font>
<font size="6">`mov ax, bx`</font>|<font size="6">`movw %bx, %ax`</font>
<font size="6">`mov eax, ebx`</font>|<font size="6">`movl %ebx, %eax`</font>
<font size="6">`mov eax, dword ptr [ebx]`</font>|<font size="6">`movl (%ebx), %eax`</font>

----

## 调试代码

```c
#include <stdio.h>

int main() {
    int a = 1, b = 1, c;
    for (int i = 0; i < 10; i++) {
        c = a + b;
        a = b;
        b = c;
    }
}
```

----

## 栈帧

一般指令执行时都会将返回的结果存储于寄存器中. 但寄存器数量很有限, 于是我们需要经常的将它存入内存. 栈帧是指为一个函数调用单独分配的那部分栈空间. 比如, 当运行中的程序调用另一个函数时,就要进入一个新的栈帧, 原来函数的栈帧称为调用者的帧, 新的栈帧称为当前帧. 被调用的函数运行结束后当前帧全部收缩, 回到调用者的帧.

----

<img src="./stack.png" width="700"/>

----

## 调试代码

```c
#include <stdio.h>

void bar(int b, int c) {
    int e = 5, f = 6;
}

void foo(int a, int b) {
    int c = 3, d = 4;
    bar(b, c);
}

int main() {
    int a = 1, b = 2;
    foo(a, b);
    return 0;
}
```

---

## OllyDbg

OllyDbg是x86调试器, 它强调二进制代码分析, 这在源代码不可用时很有用. 它跟踪寄存器, 识别过程, API调用, 开关, 表, 常数和字符串, 并从目标文件和库中查找例程. 它具有用户友好的界面, 并且可以通过第三方插件扩展其功能.

----

## [调试快捷键(OllyDbg)](https://blog.csdn.net/fengshh2301/article/details/53350443)

快捷键|功能
:-:|:-:
F2|设置断点
Ctrl+F2|重新运行程序
F7|单步步入
F8|单步步过
F9|运行程序

----

## 题目 - p1.exe

---

## IDA Pro

IDA Pro, 为Interactive Disassembler公司的反编译与除错工具的产品. 常用于逆向工程.

----

## 调试快捷键（IDA Pro）

快捷键|功能
:-:|:-:
F5|反汇编
Y|修改类型
N|重命名

----

## IDA Python

IDA6.8后自带插件, 可以使用Python做很多的辅助操作, 非常方便.

[IDAPython 让你的生活更滋润part1 and part2 - 蒸米](https://wooyun.js.org/drops/IDAPython%20%E8%AE%A9%E4%BD%A0%E7%9A%84%E7%94%9F%E6%B4%BB%E6%9B%B4%E6%BB%8B%E6%B6%A6%20part1%20and%20part2.html)

----

## 题目 - p2.exe

```python
#!/usr/bin/env python
data = '666c61677b656173795f736f5f656173797d'
flag = data.decode('hex')
print flag
```

----

## 题目 - p3

```python
#!/usr/bin/env python
data = [92, 98, 87, 93, 113, 106, 94, 95, 105, 85, 95, 105, 85, 111, 101, 107, 104, 85, 92, 95, 104, 105, 106, 85, 92, 98, 87, 93, 115]
flag = ''
for c in data:
    flag += chr(c + 10)
print flag
```

---

## GCC

GNU编译器套装, 指一套编程语言编译器, 以GPL及LGPL许可证所发行的自由软件, 也是GNU计划的关键部分, 也是GNU工具链的主要组成部分之一. GCC也常被认为是跨平台编译器的事实标准. 1985年由理查德·马修·斯托曼开始发展, 现在由自由软件基金会负责维护工作.

----

## GCC的使用

```bash
$ gcc main.c -o main -g # 编译程序, 并带上调试符号
$ ./main # 运行程序
```

----

## 设置汇编语言风格

```bash
$ objdump -d ./main -M intel # 以Intel语法展示汇编代码
$ objdump -d ./main -M att # 以AT&T语法展示汇编代码
```

----

## GDB

GNU调试器, 是GNU软件系统中的标准调试器, 此外GDB也是个具有移携性的调试器, 经过移携需求的调修与重新编译, 如今许多的类UNIX操作系统上都可以使用GDB, 而现有GDB所能支持调试的编程语言有C, C++, Pascal以及FORTRAN.

----

## [调试快捷命令(GDB)](https://blog.csdn.net/ZC20141220/article/details/77094435)

命令|功能
:-:|:-:
help(h)|输出帮助文档
start/run(r)|重新运行/继续运行
next(n)|单步步过
step(s)|单步步入
print(p)|打印

----

## [调试快捷命令(GDB)](https://blog.csdn.net/ZC20141220/article/details/77094435)

命令|功能
:-:|:-:
break(b)|设置断点
info|查看信息
continue(c)|继续运行
finish|结束当前函数
quit|退出

----

## GDB插件

- [PEDA - Python Exploit Development Assistance for GDB](https://github.com/longld/peda)
- [GEF - GDB Enhanced Features for exploit devs & reversers](https://github.com/hugsy/gef)
- [pwndbg - Exploit Development and Reverse Engineering with GDB Made Easy](http://pwndbg.re/)
- [Pwngdb - GDB for pwn](https://github.com/scwuaptx/Pwngdb)

----

## 题目 - p4

```python
#!/usr/bin/env python
data = [20, 9, 23, 2, 9, 22, 4, 1, 28, 41, 1, 23, 17, 16, 21, 2, 31, 11, 21, 44, 18, 27, 17, 30, 58, 21, 29, 16, 45, 1, 19, 7, 7, 20, 2, 23, 23, 11]
key = [114, 101, 118, 101, 114, 115, 101]
flag = ''
for i in range(len(data)):
    flag += chr(data[i] ^ key[i % 7])
print flag
```

---

## CTF中常见的逆向思路

- CTF中一般flag藏在验证函数中, 现实中的破解也是逆向验证函数的算法逻辑;
  - 理解程序逻辑, 找到验证函数, 逆推得到flag.
- 正面长驱直入: 从程序的入口点开始, 逐步分析; 层层深入最后抵达验证函数; 静态分析(生撸硬刚);
- 从信息输入/输出处寻找: 查找引用了输入输出函数的位置; 进而回溯找到验证函数;
- 利用字符串寻找: 寻找关键字符串位置从而找到验证函数.

----

## CTF中常见的逆向思路

- 没有算法;
- 常见算法: 异或, 对称加密(AES, DES等Feistel结构), 哈希算法(MD5, SHA1等), 解数学方程(线性, 矩阵), 公钥密码(逆向中比较少);
- 不一样的算法: 走迷宫, 虚拟机指令等;
- 为了增加难度, 现在CTF中经常出现一些比较少见的编程语言的逆向(如APL, Wasm等), 主要是考察选手的快速学习能力.

----

## 其他

- 需要大量的练习或实战, 才能对汇编, 各种调试技巧更加熟悉;
- 现实生活中的逆向建议在虚拟机中进行.
  - 不排除程序可能存在暗桩(会偷偷执行的代码), 可能导致重启关机或者格式化整个硬盘.

----

## References

- [Reverse 入门指南 - D0g3](https://www.d0g3.cn/re-introduction.html)
- [2017-XMan-逆向基础 - 管云超](http://blog.r4phael.cn/article/27)
- [逆向入门?别再看内些所谓从入门到高手的教程了](https://zhuanlan.zhihu.com/p/86461168)

----

## Thanks for watching

<img src="./bye.gif" width=600/>

