#include <stdio.h>
#include <stdlib.h>
#include <string.h>

//char *flag = "flag{easy_so_easy}";
char *data = "666c61677b656173795f736f5f656173797d";

int main() {
    char buffer[50];
    int len;
    printf("What's the flag? (p2)\n> ");
    scanf("%s", buffer);
    len = strlen(buffer);
    char *result = (char *)malloc(sizeof(char) * len * 2);
    for (int i = 0; i < len; i++) {
        sprintf(result + 2 * i, "%02x", buffer[i]);
    }
    if (strcmp(data, result) == 0) {
        puts("Good!");
        return 0;
    } else {
        printf("result: %s.\n", result);
        return -1;
    }
}
