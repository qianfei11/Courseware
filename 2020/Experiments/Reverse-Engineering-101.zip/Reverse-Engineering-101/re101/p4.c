#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>

//char *flag = "flag{easy_debugging_with_gnu_debugger}";
uint8_t data[] = {20, 9, 23, 2, 9, 22, 4, 1, 28, 41, 1, 23, 17, 16, 21, 2, 31, 11, 21, 44, 18, 27, 17, 30, 58, 21, 29, 16, 45, 1, 19, 7, 7, 20, 2, 23, 23, 11};
char *key = "reverse";

char *encipher(char *plaintext, int len) {
    uint8_t *ciphertext = (uint8_t *)malloc(sizeof(char) * len);
    for (int i = 0; i < len; i++) {
        *(ciphertext + i) = plaintext[i] ^ key[i % 7];
    }
    return ciphertext;
}

int main() {
    char buffer[50];
    char *ciphertext;
    int len;
    printf("What's the flag? (p4)\n> ");
    scanf("%s", buffer);
    len = strlen(buffer);
    //len = strlen(flag);
    if (len != 0x26) {
        puts("Dumb cracker...");
        return -1;
    }
    ciphertext = encipher(buffer, len);
    //ciphertext = encipher(flag, len);
    //for (int i = 0; i < len; i++) {
    //    printf("%d, ", ciphertext[i]);
    //}
    for (int i = 0; i < len; i++) {
        if (ciphertext[i] != data[i]) {
            puts("Dumb cracker...");
            return -1;
        }
    }
    puts("Damn right~");
    return 0;
}
