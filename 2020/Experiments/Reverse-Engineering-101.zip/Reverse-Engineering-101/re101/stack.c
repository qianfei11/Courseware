#include <stdio.h>

void bar(int b, int c) {
    int e = 5, f = 6;
}

void foo(int a, int b) {
    int c = 3, d = 4;
    bar(b, c);
}

int main() {
    int a = 1, b = 2;
    foo(a, b);
    return 0;
}

