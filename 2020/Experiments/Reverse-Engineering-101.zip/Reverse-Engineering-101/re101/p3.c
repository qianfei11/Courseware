#include <stdio.h>
#include <string.h>
#include <stdint.h>

//char *flag = "flag{this_is_your_first_flag}";
uint8_t data[] = {92, 98, 87, 93, 113, 106, 94, 95, 105, 85, 95, 105, 85, 111, 101, 107, 104, 85, 92, 95, 104, 105, 106, 85, 92, 98, 87, 93, 115};

int main() {
    char buffer[50];
    printf("What's the flag? (p3)\n> ");
    scanf("%s", buffer);
    int len;
    len = strlen(buffer);
    //len = strlen(flag);
    //for (int i = 0; i < len; i++) {
    //    printf("%d, ", flag[i] - 10);
    //}
    if (len != 0x1D) {
        puts("Man's not right~");
        return -1;
    }
    for (int i = 0; i < len; i++) {
        if (buffer[i] - 10 != *(data + i)) {
            puts("Man's not right~");
            return -1;
        }
    }
    puts("You nailed it!");
    return 0;
}

