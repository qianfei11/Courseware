#include <stdio.h>
#include <string.h>

char *flag = "flag{yes_you_can_reverse}";

int main() {
    char buffer[50];
    printf("What's the flag? (p1)\n> ");
    scanf("%s", buffer);
    if (strcmp(flag, buffer) == 0) {
        puts("Right~");
        return 0;
    } else {
        puts("You are wrong...");
        return -1;
    }
}
