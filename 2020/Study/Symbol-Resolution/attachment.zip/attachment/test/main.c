#include <stdio.h>
#include <string.h>

int main() {
	int x;
	scanf("%d", &x);
	printf("%d\n", x);
	return 0;
}
