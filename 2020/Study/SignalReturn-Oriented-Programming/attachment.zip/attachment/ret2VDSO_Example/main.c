#include <stdio.h>
#include <unistd.h>

char buf[10] = "/bin/sh\x00";

void pwnme() {
    char s[0x100];
	char *welcome = "> ";
    write(1, welcome, 2);
    read(0, s, 0x400);
}

int main() {
	pwnme();
	return 0;
}
