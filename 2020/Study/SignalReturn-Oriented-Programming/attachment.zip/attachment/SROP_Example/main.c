char buf[0x200];

int main()
{
    asm(
        // 读取 0x200 字节
        "mov rax, 0\n" // sys_read
        "mov rdi, 0\n" // fd
        "lea rsi, %0\n" // buf
        "mov rdx, 0x200\n" // count
        "syscall\n"

        // 恢复进程上下文
        "mov rax, 15\n" // sys_rt_sigaction
        "mov rdi, 0\n"
        "mov rsp, rsi\n"
        // syscall 的 symbol，便于查找
        "syscall:\n"
        "syscall\n"
        "jmp exit\n"

        // 退出程序
        "exit:\n"
        "mov rax, 60\n" // sys_exit
        "mov rdi, 0\n"
        "syscall\n"
        :
        : "m" (buf)
        :
        );
}
