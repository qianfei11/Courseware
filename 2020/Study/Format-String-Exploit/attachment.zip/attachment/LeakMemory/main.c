#include <stdio.h>

int main() {
	char s[100];
	int a = 1, b = 0x22222222, c = -1;
	scanf("%s", s);
	printf("%08x.%08x.%08x.%s\n", a, b, c, s);
	printf(s);
	return 0;
}
