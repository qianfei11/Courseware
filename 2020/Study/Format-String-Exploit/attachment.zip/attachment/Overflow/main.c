#include <stdio.h>

int a = 123, b = 456;

int main() {
	int c = 789;
	char s[100];
	printf("%p\n", &c);
	scanf("%s", s);
	printf(s);
	if (c == 16) {
		puts("modified c.");
	} else if (a == 2) {
		puts("modified a for a small number.");
	} else if (b == 0x12345678) {
		puts("modified b for a big number!");
	}
	return 0;
}
