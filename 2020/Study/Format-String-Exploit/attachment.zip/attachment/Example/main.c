#include <stdio.h>

int main() {
	printf("Color %s, Number %d, Float %4.2f", "red", 123456, 3.14);
	return 0;
}
