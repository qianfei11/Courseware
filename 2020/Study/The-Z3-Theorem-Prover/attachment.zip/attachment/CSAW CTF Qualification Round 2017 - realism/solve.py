#!/usr/bin/env python
from z3 import *

def z3_abs(x):
    return If(x >= 0, x, -x)

def psadbw(xmm0, xmm1):
    a = Sum([z3_abs(b1 - b2) for b1, b2 in zip(xmm0[:8], xmm1[:8])])
    b = Sum([z3_abs(b1 - b2) for b1, b2 in zip(xmm0[8:], xmm1[8:])])
    return a + b * 0x10000

s = Solver()
ZERO = IntVal(0)
xmm5 = '220f02c883fbe083c0200f10cd0013b8'.decode('hex')
xmm5 = [ord(c) for c in xmm5]
xmm5s = [xmm5]

xmm0 = [Int('x%d' % i) for i in range(16)]
for c in xmm0:
    s.add(c >= 32, c <= 126)

check = [0x02df028f, 0x0290025d, 0x02090221, 0x027b0278, 0x01f90233, 0x025e0291, 0x02290255, 0x02110270]
xmm5s += map(lambda e: [0, 0, 0, 0, 0, 0, (e >> 8) & 0xFF, e & 0xFF, 0, 0, 0, 0, 0, 0, e >> 24, (e >> 16) & 0xFF], check)
print xmm5s

for i in range(8):
    xmm5 = xmm5s[i]
    xmm2 = list(xmm0)
    xmm2[7 - i] = ZERO
    xmm2[15 - i] = ZERO
    res = psadbw(xmm5, xmm2)
    s.add(res == check[i])

if s.check() == sat:
    print s.model()
    flag = ''.join(chr(eval(str(s.model()[c]))) for c in xmm0)
    # pshufd xmm0, xmm0, 1Eh
    flag = 'flag' + flag[:4][::-1] + flag[4:8][::-1] + flag[12:][::-1] + flag[8:12][::-1]
    print flag

