#!/usr/bin/env python
from z3 import *

s = Solver()
enc = '7c153a474b6a2d3f7d3f7328703e6c2d243a083e2e773c45547748667c1511333f4f745e'.decode('hex')
flag = [Int('flag%d' % i) for i in range(len(enc) - 15)]
key = [Int('key%d' % i) for i in range(13)]
pipe = Int('pipe')

s.add(pipe == ord('|'))
for c in flag:
    s.add(c >= 0, c < 128)
for i in range(6):
    s.add(flag[i] == ord('TWCTF{'[i]))
for c in key:
    s.add(c >= 0, c < 128)

message = flag + [pipe] + key
for i in range(len(message)):
    s.add(ord(enc[i + 1]) == (ord(enc[i]) + message[i] + key[i % 13]) % 128)

if s.check() == sat:
    print s.model()
    flag = ''.join([chr(eval(str(s.model()[c]))) for c in message])
    print flag

