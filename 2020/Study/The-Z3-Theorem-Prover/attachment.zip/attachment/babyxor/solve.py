#!/usr/bin/env python
from z3 import *
import base64

enc = base64.b64decode('BCU8EGwlJzAdBjAcGCgaFxgsNyEKIy9iOBxDLwFePVtEIj1kOxBsJisnCg1jHFd4HQ0GaSYnF2wuLDIKT2MJVjxVDA5pKScQOGEuOBkGYwFMeAYLSyg3chcjYSQ0Cg9jBld4AQsZPTEgCiImYiMKBDENTCtVAgQ7ZCUCPzUnNU8aJglKK1lEBSwyNxFsKiw+GEM3AF14FxEZJy08BGwyKjACBmMHXngURAYsJTxDLS8mcR8GNxxBeAUFGD1/chAjYS44GQZjHFA5AUhLLT07DSttYjkKQy4BXzABRBgoPWhDLS0ucQIaYwRRPhBISygoPkMhOGIiGxEmBl8sHUQcLDY3QysoNDQBQzcHGCwdAUsvLTwGPzViMg4WMA0YMRtECiUochckJGImABEvDBR4AQwOaSI7BCQ1YjcAEWMcUD1VKAIrISACOCgtP08MJUh1ORsPAicgfEMEJDA0TwowSEwwEEQbOy0oBmwnLSNPFysBS3gZAR0sKGhDKi0jNhQ3Kw1nNRQDAiobJQw+JR04HDw7B0olCS0vGyceIg4QLTIsC3swTTwe')
plaintext = [BitVec('plaintext%d' % i, 8) for i in range(len(enc) - 18)]
key = [BitVec('key%d' % i, 8) for i in range(17)]
pipe = BitVec('pipe', 8)
message = plaintext + [pipe] + key

for i in range(len(enc)):
    print 'Try ==>', i
    s = Solver()
    s.add(pipe == ord('|'))
    for j in range(5):
        s.add(message[i + j] == ord('flag{'[j]))
    for c in plaintext:
        s.add(c >= 32, c <= 126)
    for c in key:
        s.add(c >= 32, c <= 126)
    s.add(pipe == ord('|'))
    for i in range(len(enc)):
        s.add(ord(enc[i]) == message[i] ^ key[i % 17])
    if s.check() == sat:
        # print s.model()
        flag = ''.join([chr(eval(str(s.model()[c]))) for c in message])
        print flag
        break

