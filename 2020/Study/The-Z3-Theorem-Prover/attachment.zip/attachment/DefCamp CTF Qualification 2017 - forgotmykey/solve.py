#!/usr/bin/env python
from z3 import *

s = Solver()
enc = '5616f5962674d26741d2810600a6c5647620c4e3d2870177f09716b2379012c342d3b584c5672195d653722443f1c39254360007010381b721c741a532b03504d2849382d375c0d6806251a2946335a67365020100f160f17640c6a05583f49645d3b557856221b2'
enc = [int(enc[2*i:2*i+2][::-1], 16) for i in range(len(enc) / 2)]
flag = [Int('flag%d' % i) for i in range(len(enc) - 34)]
key = [Int('key%d' % i) for i in range(32)]
pipe = Int('pipe')

s.add(pipe == ord('|'))
for c in flag:
    s.add(c >= 32, c < 127)
for c in key:
    s.add(c >= 32, c < 127)

for i in range(5):
    s.add(flag[i] == ord('DCTF{'[i]))
s.add(flag[-1] == ord('}'))

message = flag + [pipe] + key
for i in range(len(message)):
    s.add(enc[i + 1] == (enc[i] + message[i] + key[i % 32]) % 126)

if s.check() == sat:
    print s.model()
    flag = ''.join([chr(eval(str(s.model()[c]))) for c in message])
    print flag

