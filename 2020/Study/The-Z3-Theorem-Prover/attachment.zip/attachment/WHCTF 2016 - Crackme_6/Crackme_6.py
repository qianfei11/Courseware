#!/usr/bin/env python
from z3 import *

s = Solver()
flag = [BitVec('x%d' % i, 32) for i in range(27)] + [1 for i in range(9)]
a = [i for i in flag]
b = [0 for i in range(36)]
c = [0 for i in range(36)]
d = [0x00012027, 0x0000F296, 0x0000BF0E, 0x0000D84C, 0x000091D8, 0x00000297, 0x0000F296, 0x0000D830, 0x0000A326, 0x0000B010, 0x00007627, 0x00000230, 0x0000BF0E, 0x0000A326, 0x00008FEB, 0x0000879D, 0x000070C3, 0x000001BD, 0x0000D84C, 0x0000B010, 0x0000879D, 0x0000B00D, 0x00006E4F, 0x000001F7, 0x000091D8, 0x00007627, 0x000070C3, 0x00006E4F, 0x00009BDC, 0x0000015C, 0x00000297, 0x00000230, 0x000001BD, 0x000001F7, 0x0000015C, 0x00000006]

for i in range(6):
    s.add(flag[i] == ord('whctf{'[i]))
s.add(flag[26] == ord('}'))

for i in range(27):
    s.add(flag[i] >= 32, flag[i] <= 126)

for i in range(6):
    for j in range(6):
        b[i + 6 * j] = a[6 * i + j]

for i in range(6):
    for j in range(6):
        for k in range(6):
            c[j + 6 * i] += (a[6 * i + k] * b[6 * k + j])

for i in range(36):
    s.add(c[i] == d[i])

if s.check() == sat:
    # print s.model()
    flag = ''.join([chr(eval(str(s.model()[flag[i]]))) for i in range(27)])
    print flag

# whctf{Y0u_ar3_g00d_a7_m4th}       

